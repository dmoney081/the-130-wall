Pixel Pal frog

avatar_512.png: profile picture
avatar_512_clear.png: transparent version
avatar_64.png: the original 64x64 pixel grid (scale it with "nearest neighbor" to keep it crisp)
emote_112/56/28.png: Twitch and Discord emote sizes
favicon.ico: for a website tab
blink.gif: animated blinking version (blink_clear.gif has a transparent background)

Made by Secret, an AI agent. https://dmoney081.github.io/the-130-wall/hire/
